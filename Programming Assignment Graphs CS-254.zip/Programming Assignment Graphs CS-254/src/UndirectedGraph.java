import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Stack;


public class UndirectedGraph {

	/* vertices will store the name of a vertex (String) as the key that maps 
	 * to a Linked List of Vertex objects. This will provide the adjacency list
	 * for our UndirectedGraph */
	private HashMap<String, LinkedList<Vertex>> vertices;
	/** listOfVertices is an ArrayList of Vertex objects for all vertices in our graph */
	private ArrayList<Vertex> listOfVertices;
	
	/**
	 * UndirectedGraph constructor to assign listOfVertices and construct the HashMap vertices.
	 * @param listOfVertices - ArrayList of Vertex objects for all vertices in the graph
	 * */
	public UndirectedGraph(ArrayList<Vertex> listOfVertices) {
		vertices = new HashMap< String, LinkedList<Vertex> >();
		for(int i=0; i < listOfVertices.size(); i++)
		{
			vertices.put(listOfVertices.get(i).getName(), new LinkedList<Vertex>());
		}
		this.listOfVertices = listOfVertices;
	}
		/**
		 * addEdge - adds edge to the graph by adding Vertex v to key in vertices and
		 * adding Vertex u to key v in vertices. Both directions must be added for edge.
		 * @param u - Vertex incident on edge
		 * @param v - Vertex incident on edge
		 * @return true if edge added to graph added to graph from u to v and v to u, false otherwise
		 * */
	public boolean addEdge(Vertex u, Vertex v) {
		return(vertices.get(u.getName()).add(v) && vertices.get(v.getName()).add(u));
	}
	
	public String toString() {
		String s = "Adjaency list for graph:\n";
		for(String key : vertices.keySet()) {
			s += "Vertex "+key+":";
			LinkedList<Vertex> adjacentNodes = vertices.get(key);
			Iterator<Vertex> iterator = adjacentNodes.iterator();
			while(iterator.hasNext())
			{
				Vertex vertex = iterator.next();
				s += " ->" + vertex;
			}
			s += "\n";
			}
		return s;
		}
	
	//ALGORITHM Iterative BreadthFirstSearch(Graph G, Vertex start)
	//Traverses a graph using the breadth first methodology
	//Input: A Graph G that is a connected and undirected graph. //Vertex start is the vertex to start the traversal.
	//Output: Graph tree that represents the breadth first search tree traversal.
	public UndirectedGraph breadthFirstSearch(Vertex start)
	{
		for(int i = 0; i < listOfVertices.size(); i++) 
		{
			listOfVertices.get(i).setColor(1);// mark all vertices as white
		}
		UndirectedGraph T = new UndirectedGraph(listOfVertices);
		LinkedList<Vertex> Q = new LinkedList<Vertex>();
		Q.add(start);
		while(Q.size() > 0) //while Q is not empty
		{
			Vertex u = Q.removeFirst(); // u = Dequeue Q
			for(Vertex v: vertices.get(u.getName())) //for each v adjacent to u do
			{
				if(v.getColor() == 1) //if(v->color == WHITE)
				{
					v.setColor(2); //v->color = GREEN
					Q.addLast(v); //Enqueue to Q Vertex V
					T.addEdge(u, v); //Tree T add edge(u,v)
				}//end if
			}//end for each
			u.setColor(3); //u->color = BLACK
		}//end while
		return T;
	}//end BFS
	
	//ALGORITHM Iterative DepthFirstSearch( Vertex start)
	//Traverses a graph using the depth first methodology
	//Input: A graph that is a connected and undirected.
	//Vertex start is the vertex to start the traversal.
	//Output: Graph tree that represents the depth first search tree.

	public UndirectedGraph depthFirstSearch(Vertex start)
	{
		Stack<Vertex> S = new Stack<Vertex>();
		ArrayList<Vertex> visited = new ArrayList<Vertex>(); // store order of vistited vertices
		HashMap<Vertex, Vertex> predecessor = new HashMap<Vertex, Vertex>(); //store predecessor value
		for(int i = 0; i < listOfVertices.size(); i++)
		{
			listOfVertices.get(i).setVisited(false); //initialize each vertex u in the graph to set visited false
		}
		
		Vertex u;
		S.push(start); //push Vertex start onto S
		
		while(S.size() > 0) //while S in not empty do
		{
			u = S.pop(); //u = pop S
			if(u.isVisited() == false) // if u is not visited
			{
				u.setVisited(true); // set u visited = true
				visited.add(u);//add u to visited
				for(Vertex w: vertices.get(u.getName()))//for each unvisited neighbor w of u do
				{
					if(w.isVisited() == false)//if w not visited do
					{
						S.push(w);//push Vertex w onto S
						predecessor.put(w, u); //put w as key and u as value predecessor Hashmap
					}
				}//end for
			}//end if
		}//end while
		UndirectedGraph T = new UndirectedGraph(visited); // create Undirected graph tree with vertices visited
		for(Vertex v: visited)//for each v stored in visited do
		{
			if(predecessor.containsKey(v))//if predecessor contains key for v
			{
				u = predecessor.get(v);//get Vertex u from predecessor
				T.addEdge(u, v);
			}//end if
		}//end for
		return T;
	}//end DFS
	
}